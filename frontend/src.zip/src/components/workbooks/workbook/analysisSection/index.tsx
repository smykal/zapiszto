import React, { Component } from 'react';

class AnalysisSection extends Component {
  render() {
    return (
      <div>
        <p>analizy</p>
      </div>
    );
  }
}

export default AnalysisSection;
