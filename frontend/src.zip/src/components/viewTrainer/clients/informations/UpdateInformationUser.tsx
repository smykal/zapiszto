import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import InvitationsService from '../../../../services/invitations';
import { Invitation } from '../../../../types/types';

interface UpdateInformationUserProps {
  clientId: string;
  onUserUpdated: (selectedInviteeId: number) => void;
}

const UpdateInformationUser: React.FC<UpdateInformationUserProps> = ({ clientId, onUserUpdated }) => {
  const [acceptedInvitations, setAcceptedInvitations] = useState<Invitation[]>([]);
  const [selectedInviteeId, setSelectedInviteeId] = useState<number | null>(null);
  const { t } = useTranslation('global');

  useEffect(() => {
    fetchAcceptedInvitations();
  }, []);

  const fetchAcceptedInvitations = async () => {
    try {
      const response = await InvitationsService.getAcceptedInvitations();
      if (Array.isArray(response.data)) {
        setAcceptedInvitations(response.data);
      } else {
        console.error('Unexpected response data format:', response.data);
      }
    } catch (error) {
      console.error('Error fetching accepted invitations:', error);
    }
  };

  const handleInviteeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedInviteeId(parseInt(e.target.value, 10));
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedInviteeId === null) {
      console.error('No invitee selected');
      return;
    }
    onUserUpdated(selectedInviteeId);
  };

  return (
    <form onSubmit={handleUpdateUser}>
      <select value={selectedInviteeId || ''} onChange={handleInviteeChange}>
        <option value="">{t('clients.select_user_to_assign')}</option>
        {acceptedInvitations.map(invitation => (
          <option key={invitation.inviteeId} value={invitation.inviteeId}>
            {invitation.inviteeEmail}
          </option>
        ))}
      </select>
      <button type="submit">{t('buttons.update')}</button>
    </form>
  );
};

export default UpdateInformationUser;
