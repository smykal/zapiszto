const TrainerView = () => {
    return (
      <div>
        <h1>Trainer View</h1>
        <p>Welcome to the Trainer View. Here you can manage your training sessions and clients.</p>
      </div>
    );
  };
  
  export default TrainerView;
  